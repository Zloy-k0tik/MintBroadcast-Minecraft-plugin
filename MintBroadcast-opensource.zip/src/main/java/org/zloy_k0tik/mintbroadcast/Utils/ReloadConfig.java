package org.zloy_k0tik.mintbroadcast.Utils;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.zloy_k0tik.mintbroadcast.Main;

public class ReloadConfig {

    private final Main plugin;
    FileConfiguration config = Main.getPlugin().getConfig();

    public ReloadConfig(Main plugin) {
        this.plugin = plugin;
    }

    public void Reload(CommandSender p) {
        plugin.reloadConfig();
        plugin.getServer().getPluginManager().disablePlugin(plugin);
        plugin.getServer().getPluginManager().enablePlugin(plugin);
        String a = config.getString("messages.pluginReloaded");
        a = a.replace("[pluginPrefix]", config.getString("messages.pluginPrefix"));
        p.sendMessage(ChatColor.translateAlternateColorCodes('&', a));
    }

}
