package org.zloy_k0tik.mintbroadcast;

import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import org.zloy_k0tik.mintbroadcast.Commands.BroadcastCommand;
import org.zloy_k0tik.mintbroadcast.Commands.MainCommand;

public final class Main extends JavaPlugin {

    static Main plugin;
    public final static String version = "1.1";
    public final static String gitHubUrl = "https://github.com/Zloy-k0tik/MintBroadcast-Minecraft-plugin";

    @Override
    public void onEnable() {

        plugin = this;

        this.getConfig().options().copyDefaults();
        this.saveDefaultConfig();

        this.getLogger().info(ChatColor.translateAlternateColorCodes('&', "&aPlugin loaded..."));
        this.getLogger().info(ChatColor.translateAlternateColorCodes('&', "&fAuthor&7: &aZloy_k0tik"));
        this.getLogger().info(ChatColor.translateAlternateColorCodes('&', "&fVersion&7: &a" + version));
        this.getLogger().info(ChatColor.translateAlternateColorCodes('&', "&fGitHub&7: &a" + gitHubUrl));
        this.getCommand("mintbroadcast").setExecutor(new MainCommand());
        this.getCommand("broadcast").setExecutor(new BroadcastCommand());

    }

    public static Main getPlugin() {
        return plugin;
    }

}
