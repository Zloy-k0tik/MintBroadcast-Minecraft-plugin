package org.zloy_k0tik.mintbroadcast.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.NotNull;
import org.zloy_k0tik.mintbroadcast.Main;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BroadcastCommand implements CommandExecutor {

    FileConfiguration config = Main.getPlugin().getConfig();

    @Override
    public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {

        CommandSender p = commandSender;

        if(!(p.hasPermission("mintbroadcast.broadcast"))) {
            String a = config.getString("messages.notPermission");
            a = a.replace("[pluginPrefix]", config.getString("messages.pluginPrefix"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', a));
            return false;
        }

        if(strings.length != 0) {

            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern(config.getString("config.timeFormatter"));

            String input_msg = String.join(" ", strings);
            String msg = config.getString("messages.message");
            msg = msg.replace("[prefix]", config.getString("messages.prefix"));
            msg = msg.replace("{msg}", input_msg);
            msg = msg.replace("{playername}", p.getName());
            msg = msg.replace("{time}", now.format(timeFormatter));
            msg = ChatColor.translateAlternateColorCodes('&', msg);

            Bukkit.broadcastMessage(msg);

            return true;
        }

        else {
            String a = config.getString("messages.usage");
            a = a.replace("[pluginPrefix]", config.getString("messages.pluginPrefix"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', a));

        }

        return false;
    }
}