package org.zloy_k0tik.mintbroadcast.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.zloy_k0tik.mintbroadcast.Main;
import org.zloy_k0tik.mintbroadcast.Utils.ReloadConfig;

import java.util.ArrayList;
import java.util.List;

public class MainCommand implements CommandExecutor, TabCompleter {

    ReloadConfig reloadConfig = new ReloadConfig(Main.getPlugin());
    FileConfiguration config = Main.getPlugin().getConfig();

    @Override
    public boolean onCommand(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {

        CommandSender p = commandSender;

        if(!(p.hasPermission("mintbroadcast.admin"))) {
            String a = config.getString("messages.notPermission");
            a = a.replace("[pluginPrefix]", config.getString("messages.pluginPrefix"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', a));
            return false;
        }

        if(strings.length < 1) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m                  &r&x&3&0&C&D&1&8&lM&x&2&B&B&1&1&7&li&x&2&6&9&6&1&5&ln&x&2&1&7&A&1&4&lt&x&2&D&2&D&2&D&lBroadcast&8&m                  "));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fAuthor&7: &x&2&A&A&C&1&6Zloy_k0tik"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fVersion&7: &x&2&A&A&C&1&6" + Main.version));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fGitHub&7: &x&2&A&A&C&1&6" + Main.gitHubUrl));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fHelp command&7: &x&2&A&A&C&1&6/mintbroadcast help"));
            return true;
        }

        if(strings[0].equalsIgnoreCase("reload")) {
            reloadConfig.Reload(p);
            return true;
        }
        else if(strings[0].equalsIgnoreCase("help")) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8&m                  &r&x&3&0&C&D&1&8&lM&x&2&B&B&1&1&7&li&x&2&6&9&6&1&5&ln&x&2&1&7&A&1&4&lt&x&2&D&2&D&2&D&lBroadcast&8&m                  "));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&f&lAvailable commands&7:"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&x&2&A&A&C&1&6/mb help &7- &fshow this title"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&x&2&A&A&C&1&6/mb reload &7- &freloads the configuration"));
            return true;
        }
        else {
            String a = config.getString("messages.unknownCommand");
            a = a.replace("[pluginPrefix]", config.getString("messages.pluginPrefix"));
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', a));
        }

        return true;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {
        List<String> tab = new ArrayList<>();

        if(strings.length == 1 && commandSender.hasPermission("mintbroadcast.admin")) {
            tab.add("reload");
            tab.add("help");
        }

        return tab;
    }
}
